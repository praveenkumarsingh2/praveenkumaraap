package tabian.com.instagramclone2.materialcamera.internal;

/** @author Aidan Follestad (afollestad) */
interface CameraUriInterface {

  String getOutputUri();

}
