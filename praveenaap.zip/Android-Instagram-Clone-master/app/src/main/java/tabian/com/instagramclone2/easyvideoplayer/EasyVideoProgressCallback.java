package tabian.com.instagramclone2.easyvideoplayer;

/** @author Aidan Follestad (afollestad) */
public interface EasyVideoProgressCallback {

  void onVideoProgressUpdate(int position, int duration);
}
